# Laravel-Admin-Dashboard-Inventory-Management-
Laravel Admin Dashboard Inventory Management 


http://127.0.0.1:8000/role/list
http://127.0.0.1:8000/permission/list
