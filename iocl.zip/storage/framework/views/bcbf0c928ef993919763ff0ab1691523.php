<?php $__env->startSection('content'); ?>

    <div class="page-wrapper">
        <div class="content">

            <div class="page-header">
                <div class="page-title">
                    <h6>Location List</h6>
                </div>

                <div class="page-btn">
                    <a href="<?php echo e(route('location.create')); ?>" class="btn btn-added">
                        <img src="<?php echo e(asset('assets/img/icons/plus.svg')); ?>" alt="img" class="me-2">
                        Add Location
                    </a>
                </div>
            </div>

            <div class="card">
                <div class="card-body">

                    <!-- Filter Form -->


                    <form method="GET" action="<?php echo e(route('location.list')); ?>">
                        <div class="row">

                            <!-- Product Name -->
                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <input type="text" name="name" value="<?php echo e(request('name')); ?>"
                                        placeholder="Enter Location Name" class="form-control">
                                </div>
                            </div>



                            <!-- Buttons -->
                            <div class="col-lg-3 col-sm-6 col-12 ms-auto">
                                <div class="form-group d-flex align-items-center gap-2">
                                    <button type="submit" class="btn btn-primary px-4">
                                        Search
                                    </button>

                                    <a href="<?php echo e(route('location.list')); ?>" class="btn btn-secondary px-4">
                                        Reset
                                    </a>
                                </div>
                            </div>

                        </div>
                    </form>

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Location Name</th>
                                    <th>Cylinder Categories & Price</th>
                                    <th>Date Created</th>
                                    <th>Created By</th>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('super_admin')): ?>
                                    <th>Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($location->location_name); ?></td>


                                        <td>
                                            <?php $__currentLoopData = $location->locationCylinderCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    <strong><?php echo e($category->category->name); ?></strong>
                                                    - ₹<?php echo e(number_format($category->price, 2)); ?>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>


                                        <td>

                                            <?php echo e($location->created_at->format('d/m/Y')); ?>

                                        </td>
                                        
                                        <td> <?php echo e(ucfirst(str_replace('_', ' ', $location->creator->getRoleNames()->first() ?? 'No Role'))); ?>

                                        </td>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('super_admin')): ?>
                                            <td>
                                                <a href="<?php echo e(route('location.edit', $location->id)); ?>"
                                                    class="btn btn-sm btn-primary">
                                                    Edit
                                                </a>
                                            </td>
                                        <?php endif; ?>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">
                                            No locations found.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>

                        </table>
                    </div>
                    <div class="pagination-wrapper">
                        <?php echo e($locations->links()); ?>

                    </div>

                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iocl\resources\views/location/index.blade.php ENDPATH**/ ?>