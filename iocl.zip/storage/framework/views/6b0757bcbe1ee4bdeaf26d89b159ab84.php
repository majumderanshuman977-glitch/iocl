<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="<?php echo e(set_active(['home'])); ?>">
                    <a href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e(asset('assets/img/icons/dashboard.svg')); ?>" alt="img">
                        <span>Dashboard</span>
                    </a>
                </li>
                
                
                
                
                

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_users')): ?>
                    <li class="submenu">
                        <a href="javascript:void(0);">
                            <img src="<?php echo e(asset('assets/img/icons/users1.svg')); ?>" alt="img">
                            <span>Users</span>
                            <span class="menu-arrow"></span>
                        </a>

                        <ul>
                            <li><a href="<?php echo e(route('user.superadmin')); ?>"
                                    class="<?php echo e(set_active(['user/super-admin', 'user/super-admin/create', 'user/super-admin/edit/{id}', 'user/permissions/super-admin'])); ?>">Super
                                    Admin</a>
                            </li>
                            <li><a href="<?php echo e(route('user.subadmin')); ?>"
                                    class="<?php echo e(set_active(['user/sub-admin', 'user/sub-admin/create', 'user/sub-admin/edit/{id}', 'user/permissions/sub-admin'])); ?>">Sub
                                    Admin</a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>

                
                <li>
                    <a href="<?php echo e(route('location.list')); ?>"
                        class="<?php echo e(set_active(['location/list', 'location/create', 'location/edit/{id}'])); ?>">
                        <img src="<?php echo e(asset('assets/img/icons/users1.svg')); ?>" alt="img">
                        <span>Locations</span>
                    </a>
                </li>



                
                <li>
                    <a href="<?php echo e(route('delivery-boy.list')); ?>"
                        class="<?php echo e(set_active(['delivery-boy/list', 'delivery-boy/create', 'delivery-boy/edit/{id}'])); ?>">
                        <img src="<?php echo e(asset('assets/img/icons/users1.svg')); ?>" alt="img">
                        <span>Delivery Boys</span>
                    </a>
                </li>

                
                

                
                <li>
                    <a href="<?php echo e(route('products.list')); ?>"
                        class="<?php echo e(set_active(['products/list', 'products/create', 'products/edit/{id}'])); ?>">
                        <img src="<?php echo e(asset('assets/img/icons/users1.svg')); ?>" alt="img">
                        <span>Products</span>
                    </a>
                </li>

                
                
                
                <li class="submenu">
                    <a href="javascript:void(0);">
                        <img src="<?php echo e(asset('assets/img/icons/users1.svg')); ?>" alt="img">
                        <span>New Connections</span>
                        <span class="menu-arrow"></span>
                    </a>

                    <ul>
                        <li><a href="<?php echo e(route('customers.index')); ?>"
                                class="<?php echo e(set_active(['new-connection/customers'])); ?>">
                                Customers</a>
                        </li>

                    </ul>
                </li>

                

                

                


            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\iocl\resources\views/sidebar/sidebar.blade.php ENDPATH**/ ?>