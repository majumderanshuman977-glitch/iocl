<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>Permission Management</h4>
                    <h6>Assign Permissions</h6>
                </div>
            </div>

            <div class="card">
                <div class="card-body">

                    <form action="<?php echo e(route('user.permission.assign')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label>Select Permissions</label>
                                           <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                    <div class="row">
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-lg-3 col-sm-6 col-12 mb-2">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="permissions[]"
                                                        value="<?php echo e($permission->name); ?>" id="perm<?php echo e($permission->id); ?>"
                                                        <?php echo e(in_array($permission->name, $userPermissions) ? 'checked' : ''); ?>>

                                                    <label class="form-check-label" for="perm<?php echo e($permission->id); ?>">
                                                        <?php echo e(Str::title(str_replace('_', ' ', $permission->name))); ?>

                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Buttons -->
                            <div class="col-lg-12">
                                <button type="submit" class="btn btn-submit me-2">
                                    Save Permissions
                                </button>


                                    <?php if($user->hasRole('super_admin')): ?>
                                 <a href="<?php echo e(route('user.superadmin')); ?>" class="btn btn-cancel">
                                    Cancel
                                </a>

                                <?php else: ?>
                                <a href="<?php echo e(route('user.subadmin')); ?>" class="btn btn-cancel">
                                    Cancel
                                </a>
                                    <?php endif; ?>

                            </div>

                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iocl\resources\views/user/permissions.blade.php ENDPATH**/ ?>