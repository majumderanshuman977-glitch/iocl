<?php $__env->startSection('content'); ?>
    <!-- Page-content -->
    <div class="page-wrapper">
        <div class="content">
            <div class="row">
                
                
                
                
                <div class="col-lg-3 col-sm-6 col-12 d-flex">
                    <div class="dash-count">
                        <div class="dash-counts">
                            <h4><?php echo e($super_admin); ?></h4>
                            <h5>Active Super Admin</h5>
                        </div>
                        <div class="dash-imgs">
                             <i data-feather="user-check"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 d-flex">
                    <div class="dash-count das1">
                        <div class="dash-counts">
                            <h4><?php echo e($sub_admin); ?></h4>
                            <h5>Active Sub Admin</h5>
                        </div>
                        <div class="dash-imgs">
                            <i data-feather="user-check"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 d-flex">
                    <div class="dash-count das2">
                        <div class="dash-counts">
                            <h4><?php echo e($delivery_boys); ?></h4>
                            <h5>Active Delivery Boys</h5>
                        </div>
                        <div class="dash-imgs">
                            <i data-feather="user-check"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 d-flex">
                    <div class="dash-count das3">
                        <div class="dash-counts">
                            <h4><?php echo e($customers); ?></h4>
                            <h5>Active Customers</h5>
                        </div>
                        <div class="dash-imgs">
                            <i data-feather="user-check"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                
                <div class="col-lg-5 col-sm-12 col-12 d-flex">
                    
                    
                    
                    
                </div>
            </div>
            
        </div>
    </div>
    <!-- End Page-content -->
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iocl\resources\views//dashboard/home.blade.php ENDPATH**/ ?>