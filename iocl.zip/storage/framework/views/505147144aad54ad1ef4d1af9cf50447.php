<?php $__env->startSection('content'); ?>

    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>New Customer</h4>
                    <h6>Manage Customer</h6>
                </div>
                <div class="page-btn">
                    <a class="btn btn-added" data-bs-toggle="modal" data-bs-target="#addCustomer">
                        <img src="<?php echo e(asset('assets/img/icons/plus.svg')); ?>" alt="img" class="me-1">Add New Customer

                    </a>
                </div>
            </div>

            <div class="card">
                <div class="card-body">


                    <form method="GET" action="<?php echo e(route('customers.index')); ?>">
                        <div class="row">
                            <div class="col-lg-5 col-sm-6 col-12">
                                <div class="form-group">
                                    <input type="text" name="name" value="<?php echo e(request('name')); ?>"
                                        placeholder="Enter Customer Name/Mobile Number/Address" class="form-control">
                                </div>
                            </div>

                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <select name="status" class="form-control">
                                        <option value="">All Status</option>
                                        <option value="0"
                                            <?php echo e(request('status') !== null && request('status') == 0 ? 'selected' : ''); ?>>
                                            Inactive
                                        </option>
                                        <option value="1" <?php echo e(request('status') == 1 ? 'selected' : ''); ?>>
                                            Active
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-2 col-sm-6 col-12 ms-auto">
                                <div class="form-group d-flex align-items-center gap-2">
                                    <button type="submit" class="btn btn-filters px-5 py-3">
                                        <img src="<?php echo e(asset('assets/img/icons/search-whites.svg')); ?>" class="me-2">
                                        Search
                                    </button>

                                    <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-filters px-5 py-3">
                                        <img src="<?php echo e(asset('assets/img/icons/closes.svg')); ?>" class="me-2">
                                        Reset
                                    </a>


                                </div>
                            </div>
                        </div>
                    </form>

                    <div class="table-top">
                        <div class="search-set">
                            <div class="search-input">
                                <a class="btn btn-searchset">
                                    <img src="<?php echo e(asset('assets/img/icons/search-white.svg')); ?>" alt="img">
                                </a>
                            </div>
                        </div>

                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>

                                    <th>Customer Name</th>
                                    <th>Mobile Number</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>Created By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo e($customer->customer_name); ?></td>
                                        <td><?php echo e($customer->mobile_number); ?></td>
                                        <td><?php echo e($customer->address); ?></td>
                                        <td>
                                            <div class="status-toggle d-flex justify-content-between align-items-center">
                                                <input type="checkbox" id="customer<?php echo e($customer->id); ?>"
                                                    class="check customer-status" data-id="<?php echo e($customer->id); ?>"
                                                    <?php echo e($customer->status === 1 ? 'checked' : ''); ?>>
                                                <label for="customer<?php echo e($customer->id); ?>"
                                                    class="checktoggle">checkbox</label>
                                            </div>
                                        </td>
                                        <td>
                                            <?php echo e(ucfirst(str_replace('_', ' ', $customer->creator->getRoleNames()->first() ?? 'No Role'))); ?>

                                        </td>


                                        <td>
                                            <a class="btn btn-sm btn-primary editCustomerBtn" href="javascript:void(0);"
                                                data-id="<?php echo e($customer->id); ?>" data-bs-toggle="modal"
                                                data-bs-target="#editCustomer">
                                                Edit
                                            </a>


                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="pagination-wrapper">
                        <?php echo e($customers->links()); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>


    
    <div class="modal fade" id="addCustomer" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Add Customer </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>


                <form action="<?php echo e(route('customers.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="modal-body">
                        <div class="row">

                            <!-- Customer Name -->
                            <div class="col-12 mb-3">
                                <label class="form-label">
                                    Customer Name <span class="text-danger">*</span>
                                </label>
                                <input type="text" name="customer_name" value="<?php echo e(old('customer_name')); ?>"
                                    class="form-control <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Phone -->
                            <div class="col-12 mb-3">
                                <label class="form-label">
                                    Phone Number <span class="text-danger">*</span>
                                </label>
                                <input type="tel" name="mobile_number" value="<?php echo e(old('mobile_number')); ?>"
                                    class="form-control <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>

                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Address -->
                            <div class="col-12 mb-3">
                                <label class="form-label">
                                    Address <span class="text-danger">*</span>
                                </label>
                                <textarea name="address" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3" required><?php echo e(old('address')); ?></textarea>

                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- ID Number -->
                            <div class="col-12 mb-3">
                                <label class="form-label">ID Number</label>
                                <input type="text" name="id_number" value="<?php echo e(old('id_number')); ?>"
                                    class="form-control <?php $__errorArgs = ['id_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                <?php $__errorArgs = ['id_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- ID Proof File -->
                            <div class="col-12 mb-3">
                                <label class="form-label">Upload ID Proof</label>
                                <div class="mb-2" id="addIdPreviewContainer" style="display:none;"
                                    onclick="window.open(this.src, '_blank')">
                                    <img id="addIdPreview" src="" alt="ID Proof Preview"
                                        style="max-width:150px; max-height:120px; border:1px solid #ddd; padding:5px; border-radius:5px; object-fit:cover;">
                                </div>
                                <input type="file" name="id_file" id="addIdFile"
                                    class="form-control <?php $__errorArgs = ['id_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                <?php $__errorArgs = ['id_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">
                            Save Customer
                        </button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            Cancel
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>


    
    <div class="modal fade" id="editCustomer" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Edit Customer </h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form id="editForm" method="POST" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>

                    <div class="modal-body">
                        <div class="row">

                            <!-- Customer Name -->
                            <div class="col-12 mb-3">
                                <label class="form-label">
                                    Customer Name <span class="text-danger">*</span>
                                </label>
                                <input type="text" name="customer_name" id="editCustomerName" class="form-control"
                                    required>
                                <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Phone -->
                            <div class="col-12 mb-3">
                                <label class="form-label">
                                    Phone Number <span class="text-danger">*</span>
                                </label>
                                <input type="text" name="mobile_number" id="editPhone" class="form-control" required>
                                <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Address -->
                            <div class="col-12 mb-3">
                                <label class="form-label">
                                    Address <span class="text-danger">*</span>
                                </label>
                                <textarea name="address" id="editAddress" class="form-control" rows="3" required></textarea>
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>



                            <div class="col-12 mb-3">
                                <label class="form-label">ID Number</label>
                                <input type="text" name="id_number" id="editIdNumber" class="form-control">
                                <?php $__errorArgs = ['id_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="col-12 mb-3">
                                <label class="form-label">Upload New ID Proof</label>

                                <!-- Old Image Preview -->
                                <div class="mb-2" id="oldIdPreviewContainer" style="display:none;">
                                    <img id="oldIdPreview" src="" alt="ID Proof"
                                        onclick="window.open(this.src, '_blank')"
                                        style="max-width:150px; max-height:120px; border:1px solid #ddd; padding:5px; border-radius:5px;">
                                </div>

                                <input type="file" name="id_file" id="editIdFile" class="form-control">

                                <?php $__errorArgs = ['id_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">
                            Update Customer
                        </button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            Cancel
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>


<?php $__env->startSection('script'); ?>
    <script>
        document.getElementById('addIdFile').addEventListener('change', function() {
            const file = this.files[0];

            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    document.getElementById('addIdPreview').src = e.target.result;
                    document.getElementById('addIdPreviewContainer').style.display = 'block';
                };

                reader.readAsDataURL(file);
            } else {
                document.getElementById('addIdPreview').src = '';
                document.getElementById('addIdPreviewContainer').style.display = 'none';
            }
        });

        document.querySelectorAll('.editCustomerBtn').forEach(button => {
            button.addEventListener('click', function() {
                let id = this.getAttribute('data-id');
                let name = this.getAttribute('data-name');




                document.getElementById('editForm').action = '/new-connection/customers/' + id;


                fetch('/new-connection/customers/' + id + '/edit')
                    .then(res => res.json())
                    .then(data => {
                        document.getElementById('editCustomerName').value = data.customer_name;
                        document.getElementById('editPhone').value = data.mobile_number ?? '';
                        document.getElementById('editAddress').value = data.address ?? '';
                        document.getElementById('editIdNumber').value = data.id_proof_number ?? '';


                        if (data.id_proof) {
                            document.getElementById('oldIdPreview').src = '/storage/' + data.id_proof;
                            document.getElementById('oldIdPreviewContainer').style.display = 'block';
                        } else {
                            document.getElementById('oldIdPreviewContainer').style.display = 'none';
                        }
                    })
                    .catch(() => Swal.fire('Error', 'Failed to load customer data', 'error'));
            });
        });


        document.getElementById('editIdFile').addEventListener('change', function() {
            const file = this.files[0];

            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    document.getElementById('oldIdPreview').src = e.target.result;
                    document.getElementById('oldIdPreviewContainer').style.display = 'block';
                };

                reader.readAsDataURL(file);
            } else {

                document.getElementById('oldIdPreview').src = '';
                document.getElementById('oldIdPreviewContainer').style.display = 'none';
            }
        });
    </script>

    <script>
        document.addEventListener('change', function(e) {

            if (e.target.classList.contains('customer-status')) {

                let checkbox = e.target;
                let userId = checkbox.dataset.id;
                let status = checkbox.checked ? 1 : 0;

                fetch("<?php echo e(route('customer.status.update')); ?>", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                        },
                        body: JSON.stringify({
                            id: userId,
                            status: status
                        })
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire('Success', 'Customer status updated successfully', 'success');
                        }
                    })
                    .catch(() => {
                        checkbox.checked = !checkbox.checked;
                        Swal.fire('Error', 'Something went wrong', 'error');
                    });
            }

        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iocl\resources\views/customer/index.blade.php ENDPATH**/ ?>