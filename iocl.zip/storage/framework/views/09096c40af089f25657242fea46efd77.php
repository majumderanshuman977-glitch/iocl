<?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>Super Admin Management</h4>
                <h6>Update Super Admin</h6>
            </div>
        </div>

        <div class="card">
            <div class="card-body">

                <form action="<?php echo e(route('user.update', $user->id)); ?>"
                      method="POST"
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row">

                        <!-- Left column -->
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name"
                                       class="form-control"
                                       value="<?php echo e(old('name', $user->name)); ?>" required>
                                       <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                         <span class="text-danger"><?php echo e($message); ?></span>
                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label>Email</label>
                                <input type="text" name="email"
                                       class="form-control"
                                       value="<?php echo e(old('email', $user->email)); ?>">
                                       <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                           <span class="text-danger"><?php echo e($message); ?></span>
                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label>Password (leave blank to keep)</label>
                                <div class="pass-group">
                                    <input type="password"
                                           name="password"
                                           class="pass-input form-control">
                                    <span class="fas toggle-password fa-eye-slash"></span>
                                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       <span class="text-danger"><?php echo e($message); ?></span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Middle column -->
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Mobile</label>
                                <input type="text" name="mobile"
                                       class="form-control"
                                       value="<?php echo e(old('mobile', $user->mobile)); ?>" required>
                                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                             <span class="text-danger">
                                                <?php echo e($message); ?>

                                             </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
<input type="hidden" name="roles[]" value="super_admin">

                            <div class="form-group">
                                <label>Confirm Password</label>
                                <div class="pass-group">
                                    <input type="password"
                                           name="password_confirmation"
                                           class="pass-input form-control">
                                    <span class="fas toggle-passworda fa-eye-slash"></span>
                                   <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger">
                                        <?php echo e($message); ?>

                                    </span>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Image column -->
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Profile Picture</label>

                                <div class="image-upload image-upload-new">
                                    <input type="file"
                                           name="profile_image"
                                           id="imageInput"
                                           accept="image/*">

                                    <div class="image-uploads">
                                        <img id="previewImage"
                                             src="<?php echo e($user->avatar ? asset('storage/'.$user->avatar) : ''); ?>"
                                             style="max-width:120px; margin-bottom:10px;">
                                        <h4>Click or drag image to upload</h4>
                                    </div>
                                     <?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger">
                                            <?php echo e($message); ?>

                                        </span>

                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Buttons -->
                        <div class="col-lg-12">
                            <button type="submit" class="btn btn-submit me-2">
                                Update
                            </button>
                            <a href="<?php echo e(route('user.superadmin')); ?>" class="btn btn-cancel">
                                Cancel
                            </a>
                        </div>

                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
document.getElementById('imageInput').addEventListener('change', function(e) {
    let reader = new FileReader();
    reader.onload = function(event) {
        document.getElementById('previewImage').src = event.target.result;
    };
    reader.readAsDataURL(e.target.files[0]);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iocl\resources\views/user/superadmin_edit.blade.php ENDPATH**/ ?>