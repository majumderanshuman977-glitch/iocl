<?php $__env->startSection('content'); ?>
    <!-- Page-content -->
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>Delivery Boy List</h4>
                    <h6>Manage your Delivery Boys</h6>
                </div>


                <div class="page-btn">
                    <a href="<?php echo e(route('delivery-boy.create')); ?>" class="btn btn-added">
                        <img src="<?php echo e(asset('assets/img/icons/plus.svg')); ?>" alt="img" class="me-2">Add Delivery Boy
                    </a>
                </div>
            </div>

            <div class="card">
                <div class="card-body">


                    <form method="GET" action="<?php echo e(route('delivery-boy.list')); ?>">
                        <div class="row">
                            <div class="col-lg-4 col-sm-6 col-12">
                                <div class="form-group">
                                    <input type="text" name="name" value="<?php echo e(request('name')); ?>"
                                        placeholder="Enter Vehicle Name/Phone Number" class="form-control">
                                </div>
                            </div>


                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <select name="van_type" class="form-control">
                                        <option value="">Select Vehicle Type</option>
                                        <option value="small_van"
                                            <?php echo e(request('van_type') == 'small_van' ? 'selected' : ''); ?>>
                                            Small Van
                                        </option>
                                        <option value="large_van"
                                            <?php echo e(request('van_type') == 'large_van' ? 'selected' : ''); ?>>
                                            Large Van
                                        </option>
                                    </select>
                                </div>
                            </div>



                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <select name="status" class="form-control">
                                        <option value="">All Status</option>
                                        <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>
                                            Incative
                                        </option>
                                        <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-2 col-sm-6 col-12 ms-auto">
                                <div class="form-group d-flex align-items-center gap-2">
                                    <button type="submit" class="btn btn-filters px-5 py-3">
                                        <img src="<?php echo e(asset('assets/img/icons/search-whites.svg')); ?>" class="me-2">
                                        Search
                                    </button>

                                    <a href="<?php echo e(route('delivery-boy.list')); ?>" class="btn btn-filters px-5 py-3">
                                        <img src="<?php echo e(asset('assets/img/icons/closes.svg')); ?>" class="me-2">
                                        Reset
                                    </a>


                                </div>
                            </div>
                        </div>
                    </form>


                    <div class="table-responsive">
                        <table class="table">

                            <thead>


                                <th>Name/Vehicle</th>
                                <th>Vehicle Type </th>
                                <th>Phone</th>
                                <th>Capacity</th>
                                <th>PF/ESI Status</th>
                                <th>Status</th>
                                <th>Created By</th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_delivery_boys')): ?>
                                    <th>Action</th>
                                <?php endif; ?>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $deliveryBoy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="user-row-<?php echo e($db->id); ?>">

                                        <td>
                                            <?php if($db->van_type === 'large_van'): ?>
                                                <?php echo e($db->vehicle_name); ?>

                                            <?php else: ?>
                                                <?php echo e($db->driver_name); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e(str_replace('_', ' ', $db->van_type)); ?></td>
                                        <td><?php echo e($db->mobile_number); ?></td>
                                        <td><?php echo e($db->max_cylinder_capacity); ?></td>
                                        <td><?php echo e($db->is_pf_esi ? 'Yes' : 'No'); ?></td>

                                        <td>
                                            <div class="status-toggle d-flex justify-content-between align-items-center">
                                                <input type="checkbox" id="user<?php echo e($db->id); ?>" class="check db-status"
                                                    data-id="<?php echo e($db->id); ?>"
                                                    <?php echo e($db->status === 1 ? 'checked' : ''); ?>>
                                                <label for="user<?php echo e($db->id); ?>" class="checktoggle">checkbox</label>
                                            </div>
                                        </td>

                                        <td>
                                            <?php echo e(ucfirst(str_replace('_', ' ', $db->creator->getRoleNames()->first() ?? 'No Role'))); ?>

                                        </td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_delivery_boys')): ?>
                                            <td>
                                                <a href="<?php echo e(route('delivery-boy.edit', $db->id)); ?>"
                                                    class="btn btn-sm btn-primary">
                                                    Edit
                                                </a>

                                            </td>
                                        <?php endif; ?>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>

                    </div>

                    <div class="pagination-wrapper">
                        <?php echo e($deliveryBoy->links()); ?>

                    </div>


                </div>
            </div>

        </div>
    </div>



<?php $__env->startSection('script'); ?>
    <script>
        document.addEventListener('change', function(e) {

            if (e.target.classList.contains('db-status')) {

                let checkbox = e.target;
                let userId = checkbox.dataset.id;
                let status = checkbox.checked ? 1 : 0;

                fetch("<?php echo e(route('delivery-boy.status.update')); ?>", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                        },
                        body: JSON.stringify({
                            id: userId,
                            status: status
                        })
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire('Success', 'Delivery Boy status updated successfully', 'success');
                        }
                    })
                    .catch(() => {
                        checkbox.checked = !checkbox.checked;
                        Swal.fire('Error', 'Something went wrong', 'error');
                    });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iocl\resources\views/delivery_boy/list.blade.php ENDPATH**/ ?>